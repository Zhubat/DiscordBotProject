const db = require('quick.db');

module.exports = {
    name: "testmoney",
    aliases: ["testmoney"],
    category: "wallet",
    description: "test!",
    usage: "testmoney",
    run: async (client, message, args, tools) => {
        db.add(`userBalance_${message.author.id}`, 1000);
        return message.channel.send("successful.")
    }
}